
// KHJDeviceManager.h
// KHJCamera

#import <Foundation/Foundation.h>
#import <CoreVideo/CoreVideo.h>
#import "OpenGLView20.h"
#import "TimeInfo.h"

typedef NS_ENUM(NSInteger,KHJVideoQuality)
{
    KHJVideoQualityUnknown              = 0x00,
    KHJVideoQualityMax                  = 0x01,//HD
    KHJVideoQualityHigh                 = 0x02,//HD
    KHJVideoQualityMiddle               = 0x03,//SD
    KHJVideoQualityLow                  = 0x04,//SD
    KHJVideoQualityMin                  = 0x05
};

@interface KHJDeviceManager : NSObject

@property(nonatomic,strong) OpenGLView20 *glView;

/**
 实例化 Camera
 */
- (void)creatKHJCameraBase:(NSString *)deviceID;
- (void)creatHMCameraBase:(NSString *)deviceID;
- (void)creatMAEVIACameraBase:(NSString *)deviceID;

#pragma mark - 设备连接方法
/**
 连接设备（异步）
 
 @param pwd 密码
 @param uidStr 设备id
 @param resultBlock 成功回调
 @param offLineBlock 离线回调
 @return 连接结果
 */
- (BOOL)connect:(NSString *)pwd
        withUid:(NSString *)uidStr
successCallBack:(void(^)(NSString *uidStr,NSInteger isSuccess))resultBlock
offLineCallBack:(void(^)(void))offLineBlock;

#pragma mark - 设备重连
/**
 重连设备
 
 @param pwd 密码
 @param uidStr 设备id
 @param resultBlock 成功回调
 @param offLineBlock 离线回调
 @return 重连结果
 */
- (BOOL)reConnect:(NSString *)pwd
          withUid:(NSString *)uidStr
  successCallBack:(void(^)(NSString *uidString, NSInteger isSuccess))resultBlock
  offLineCallBack:(void(^)(void))offLineBlock;

#pragma mark - 断开连接
/**
 断开连接，返回成功/失败
 */
- (BOOL)disconnect;

#pragma mark - 添加设备后，设置账号，绑定用户与设备
/**
 添加设备后，设置账号，绑定用户与设备
 
 @param uAccount 用户账号
 @param ssid 有线连接不用传
 @param passPwd 有线连接不用传
 @param urlStr 服务器地址
 @param resultBlock
 - success YES 设置成功，NO 设置失败
 */
- (BOOL)setAccount:(NSString *)uAccount
           andSsid:(NSString *)ssid
           andSPwd:(NSString *)passPwd
        andService:(NSString *)urlStr
       returnBlock:(void(^)(BOOL success))resultBlock;

#pragma mark - 设备属性设置

#pragma mark - 检测设备状态
/*
 *查询当前是否在线
 * 0:离线 1:在线 2:正在连接
 */
- (int)checkDeviceStatus;

#pragma mark - 设置设备新密码
/**
 设置设备新密码
 流程：设备添加 - 设备主动修改设备密码，传到服务器 - app获取设备列表时，服务器返回设备密码 - app发起设备连接请求
 
 @param oldpassword 设备老密码
 @param newpassword 设备新密码
 @param uidStr 设备id
 @param resultBlock 成功回调
 */
- (void)setPassword:(NSString *)oldpassword
        Newpassword:(NSString *)newpassword
            withUid:(NSString *)uidStr
     returnCallBack:(void(^)(BOOL b))resultBlock;

#pragma mark - 设备控制

#pragma mark - 设备重启
/**
 设备重启，返回成功/失败
 */
- (BOOL)deviceReboot;

#pragma mark - 搜索局域网下所有设备
/**
 搜素局域网下所有设备
 */
+ (void)searchDevice:(void(^)(NSMutableArray *darray))resultBlock;

#pragma mark - 停止搜索设备
/**
 停止搜索设备
 */
+ (void)stopSearchDevice;

#pragma mark - 音频操作
/**
 打开音频
 */
- (void)openAudio;

/**
 关闭音频
 */
- (void)closeAudio;

/**
 停止播放音频
 */
- (void)audioPlayStop;

#pragma mark - 设备截图方法
/**
 设备截图方法
 */
- (void)getTrueIamge:(NSString *)urlString
      returnCallBack:(void(^)(BOOL b))resultBlock;

#pragma mark - 获取视频缩略图 - h264格式,h265格式
/**
 获取视频缩略图 - h264格式,h265格式
 
 @param fileName 视频文件名称
 @param outFileName 输出文件名称
 @param dWidth 图片宽
 @param dHeight 图片高
 @return 缩略图
 */
+ (UIImage *)getCoverImage:(NSString *)fileName
                outPutName:(NSString *)outFileName
                     width:(int)dWidth
                    height:(int)dHeight;

#pragma mark - 视频画面翻转180
/**
 视频画面翻转180
 
 @param derect 0: 不翻转 1: 翻转180
 @param resultBlock
 - success YES 翻转成功，NO 反转不成功
 */
- (BOOL)setFlippingWithDerect:(int)derect
                  returnBlock:(void(^)(BOOL success))resultBlock;

#pragma mark - 获取当前视频画面翻转状态
/**
 获取当前视频画面翻转状态
 
 @param resultBlock
 - success YES 已翻转180，NO 原始状态
 */
- (BOOL)getFLipping:(void(^)(BOOL success))resultBlock;

#pragma mark - SD卡操作
#pragma mark - SD卡截图
/*
 截图
 0：成功 1：没sd卡 2：失败
 */
- (BOOL)screenShot:(void(^)(BOOL b))resultBlock;

#pragma mark - SD卡开始录制视频
/**
 设备录制视频 -> SD卡
 1.由手机发送指令
 2.由嵌入式发送指令
 
 0：成功 1：没sd卡 2：失败
 */
- (BOOL)videoRecordingStart:(void(^)(BOOL b))resultBlock;

#pragma mark - SD卡结束录制视频
/**
 结束设备录制视频 -> SD卡
 
 0：成功 1：没sd卡 2：失败
 */
- (BOOL)videoRecordingStop:(void(^)(BOOL b))resultBlock;

#pragma mark - 获取SD卡中，保存的视频文件
/**
 获取SD卡中，保存的视频文件
 SD卡录制视频的3种模式：连续录像，报警录像，定时录像
 
 @param date            日期时间戳
 @param b               是否为第一页
 @param resultBlock
 - isContinue   是否还有下一页(设备记录页数)
 - mArray       下一页视频列表
 */
- (void)listVideoFileStart:(long)date
                 withStart:(bool)b
               returnBlock:(void(^)(BOOL isContinue, NSMutableArray *mArray))resultBlock;

#pragma mark - 获取SD卡的报警图片文件
/**
 获取SD卡的报警图片文件
 
 @param date            日期时间戳
 @param b               是否为第一页
 @param resultBlock
 - isContinue   是否还有下一页(设备记录页数)
 - mArray       下一页视频列表
 */
- (void)listJpegFileStart:(long)date
                withStart:(bool)b
              returnBlock:(void(^)(BOOL isContinue, NSMutableArray *mArray))resultBlock;

#pragma mark - 获取设备SD卡信息
/**
 获取设备SD卡信息
 
 @param uid 设备id
 @param resultBlock     查询返回参数
 - allCapacity     SDCard 总内存
 - leftCapacity    SDCard 剩余内存
 - version         设备固件版本
 - model           设备类型：IPC28
 - vendor          供应商
 - ffs             提醒用户需要格式化sd卡
 @return 获取结果
 */
- (BOOL)queryDeviceInfo:(NSString *)uid
            reternBlock:(void(^)(int allCapacity,
                                 int leftCapacity,
                                 int version,
                                 NSString *model,
                                 NSString *vendor,
                                 NSString *ffs))resultBlock;

#pragma mark - 指定时间戳日期内，获取SD卡中所有视频
/**
 指定时间戳日期内，获取SD卡中所有视频
 
 @param timestamp 查询时间戳
 @param resultBlock
 - success YES 获取成功，NO 获取失败
 - fileArr 文件列表
 */
- (void)getAllVedioTime:(NSTimeInterval)timestamp
            returnBlock:(void(^)(BOOL success, NSMutableArray *fileArr))resultBlock;


#pragma mark - 回放SD卡视频
/**
 回放SD卡视频
 
 @param stringVedio SD卡视频文件名称
 @param isStart 是否开始播放，YES 开始播放，NO 停止播放
 @param startP 1
 @param uidStr 设备id
 @param resultBlock
 - mTotal
 - mCurrentP
 */
- (int)playSDVideo:(NSString *)stringVedio
         withStart:(BOOL)isStart
            seekTo:(NSInteger)startP
           withUid:(NSString *)uidStr
       returnBlock:(void(^)(int mTotal,int mCurrentP))resultBlock;

#pragma mark - 下载视频文件
/**
 下载视频文件
 
 @param fileName 视频文件名称
 @param uidStr 设备id
 @param resultBlock
 - data 最新下载返回数据，可写入保存data
 - hhSize 已下载视频大小
 - totalSize 视频总大小
 */
- (int)downLoadVedioFile:(NSString *)fileName
                 withUid:(NSString *)uidStr
             returnBlock:(void(^)(NSData *data,int hhSize,int totalSize))resultBlock;

#pragma mark - 取消视频下载
/**
 取消视频下载
 */
- (void)cancelDownLoadFile;

#pragma mark - 下载图片文件
/**
 下载图片文件
 
 @param fileName 图片文件名称
 @param resultBlock
 - data 最新下载返回数据，可写入保存data
 - hhSize 已下载视频大小
 - totalSize 视频总大小
 
 @return
 -1：正在传输文件
 -2：目前设备离线，无法下载SD卡报警图片
 */
- (NSInteger)downLoadPhotoFile:(NSString *)fileName
                   returnBlock:(void(^)(NSData *data,int hhSize,int totalSize))resultBlock;

#pragma mark - 上传音频文件
/**
 通用上传文件
 
 @param fileName 文件路径
 @param name 文件名称
 @param alias 别名
 @param resultBlock
 - uint8_t:  0:成功， 1: 文件太大 2：文件正在发送 3:文件不支持 4:文件达到上限请删除后在上传 5:失败
 - uint32_t: 文件总大小
 - uint32_t: 发送了多少个字节
 
 @return
 0:  成功
 -1: 正在传输文件
 -2: 设备不再线
 -3: 文件不存在
 -4: 文件名字太长
 */
- (int)uploadAudioFile:(NSString *)fileName
                  name:(NSString *)name
                 alias:(NSString *)alias
           returnBlock:(void(^)(uint8_t success,uint32_t totalSize,uint32_t hadSendSize))resultBlock;

#pragma mark - ap模式下 离线升级，上传.img固件到
/**
 上传文件
 
 @param filePath 文件名称
 @param resultBlock
 - uint8_t:  0:成功， 1: 文件太大 2：文件正在发送 3:文件不支持 4:文件达到上限请删除后在上传 5:失败
 - uint32_t: 文件总大小
 - uint32_t: 发送了多少个字节
 
 @return
 0:  成功
 -1: 正在传输文件
 -2: 设备不再线
 -3: 文件不存在
 -4: 文件名字太长
 */
- (int)uploadFirmwareFile:(NSString *)filePath
              returnBlock:(void(^)(uint8_t success,uint32_t totalSize,uint32_t hadSendSize))resultBlock;

#pragma mark - 取消上传.img安装包

- (void)cancelUploadFirmwareFile;

#pragma mark - 删除录音文件

- (void)deleteAudioFileWithFileName:(NSString *)fileName
                          aliasName:(NSString *)aliasName
                         returnBloc:(void(^)(BOOL success))resultBlock;

#pragma mark - 设置默认音频文件

- (void)setDefaultAudioFileWithFileName:(NSString *)fileName
                              aliasName:(NSString *)aliasName
                             returnBloc:(void(^)(BOOL success))resultBlock;

#pragma mark - 播放录音文件

- (void)playAudioFileWithFileName:(NSString *)fileName
                        aliasName:(NSString *)aliasName
                       returnBloc:(void(^)(BOOL success))resultBlock;

#pragma mark - 获取录音文件列表

- (void)getRecordAudioListWithReturnBlock:(void(^)(NSMutableArray *soundNameArr, NSMutableArray *soundAliasArr, int tag))resultBlock;

#pragma mark - 手机前后台切换
#pragma mark - 摄像头进入后台
/**
 摄像头进入后台
 */
+ (void)cameraEnterBackground;

#pragma mark - 摄像头进入前台
/**
 摄像头进入前台
 */
+ (void)cameraEnterForeground;

#pragma mark - 摧毁对象
#pragma mark - 摧毁Camera对象
/**
 摧毁Camera对象
 */
- (void)destroySelf;

#pragma mark - 通知方法

#pragma mark - 注册监听设备状态
/**
 注册监听设备状态
 设备主动推送事件给app，事件类型 + 事件参数
 
 @param resultBlock
 - type     类型：0 设备开启 1 设备关闭 2 开始录屏 3 停止录屏 4  5 设备SD卡插拔 6 视频质量切换
 - dString  如：类型 == 0 类型 == 1时，不使用 dString
 类型 == 6时，会使用 dString
 - uidStr   设备id
 */
- (void)registerActivePushListener:(void(^)(int type, NSString *dString, NSString *uidStr))resultBlock;

#pragma mark - 取消监听设备状态
/**
 取消监听设备状态
 */
- (void)unregisterActivePushListener;

#pragma mark - 通知设备升级
/**
 通知设备升级
 
 @param resultBlock
 - success 0 升级成功，1 升级失败
 */
- (void)notifyUpgrade:(void(^)(int success))resultBlock;

/**
 应用退出后台超过 40s，再次进入时，调用 reinitsocket，释放资源，重新连接
 */
+ (void)reinitsocket;

#pragma mark - 开始接收视频数据 + 停止接收视频数据 ***
/**
 开启视频接收
 
 @param isReceive 是否开始接收数据，YES 开始接收数据，NO 停止接收数据
 @param uidStr 设备id
 @param resultBlock 回调方法
 */
- (BOOL)startRecvVideo:(BOOL)isReceive
               withUid:(NSString *)uidStr
           reternBlock:(void(^)(BOOL k))resultBlock;

#pragma mark - 查询是否再自动巡航
/**
 查询是否再自动巡航
 */
- (BOOL)getPtzAutoStatus:(void(^)(BOOL b))resultBlock;

#pragma mark - 获取设备录像状态
/**
 获取当前录像状态
 
 0:没有录像 1：正在录像
 */
- (int)getvideoRecordStatus;



#pragma mark - 是否播放音频
/**
 是否播放音频
 */
- (void)isPlayRecvAudio:(BOOL)isPlayAudio;

#pragma mark - 开始录制视频 + 停止录制视频 ***
/**
 开始或结束录制视频
 
 @param on 开始录制（YES）结束录制（NO）
 @param path 视频保存路径
 */
- (void)startRecordMp4:(BOOL)on path:(NSString *)path;

#pragma mark - 开始接收音频
/*
 * 实时音频线程，回放时不要打开
 *
 * param1  char *: 压缩后的数据
 * param2  unsigned int : 数据长度，每次获取的是固定的size：320
 * param3  unsigned int : pts数据时间戳
 */
- (BOOL)startRecvAudio:(BOOL)on;

#pragma mark - 摇头机转动
/**
 设置摇头机转动
 
 @param direction 转动方向
 @param step 步数
 */
- (BOOL)setRun:(NSInteger)direction withStep:(NSInteger)step;

/**
 是否录制音频
 */
- (void)delayStopRerord:(BOOL)isStop;

#pragma mark - 发送音频

/**
 发送音频
 
 @param on YES 发送音频，NO 停止发送音频
 */
- (BOOL)startSendAudio:(BOOL)on;

#pragma mark - 获取视频画面质量

/**
 获取视频画面质量
 
 @return
 - KHJVideoQualityUnknown              = 0x00,
 - KHJVideoQualityMax                  = 0x01,高清
 - KHJVideoQualityHigh                 = 0x02,高清
 - KHJVideoQualityMiddle               = 0x03,标清
 - KHJVideoQualityLow                  = 0x04,标清
 - KHJVideoQualityMin                  = 0x05流畅
 */
- (KHJVideoQuality)getVideoQuality;

#pragma mark - 获取 mac 和 ip

/**
 获取 mac 和 ip
 
 @return
 - success  0 成功 其他失败
 - mac      mac地址
 - ip       ip地址
 */
- (BOOL)getMacIp:(void(^)(int success, NSString *mac, NSString *ip))resultBlock;

#pragma mark - 格式化 SDCard
/**
 格式化 SDCard
 
 @param resultBlock
 - 0： 成功
 - -1：失败
 - -2：没有插入sdcard
 */
- (void)formatSdcard:(void(^)(int success))resultBlock;

#pragma mark - 设置时区
/**
 设置时区
 
 @param timezone 时区
 - 「 -660 -600 -540 -480 -420 -360 -300 -240 -180 -120 -60 0 60 120 180 240 300 360 420 480 540 600 660 720 」
 @param resultBlock
 -  success true 设置成功，false 设置失败
 */
- (void)setTimezone:(NSInteger)timezone returnBlock:(void(^)(BOOL success))resultBlock;

#pragma mark - 获取时区
/**
 获取时区
 
 @param resultBlock
 - success 返回时区参数
 - 「 -660 -600 -540 -480 -420 -360 -300 -240 -180 -120 -60 0 60 120 180 240 300 360 420 480 540 600 660 720 」
 */
- (void)getTimeZone:(void(^)(int success))resultBlock;



#pragma mark - 获取设备（当前连接）的网络
/**
 获取设备（当前连接）的网络
 
 @param resultBlock 0：WIFI 1：网线 2：ap热点 3：获取失败
 */
- (void)getNetworkLinkStatus:(void(^)(int mode))resultBlock;

#pragma mark - 查询设备周围的 wifi
/**
 查询设备周围的 wifi
 
 @param wifiBlock
 - connectingWifiName 正在连接的wifi网络名称
 
 @param resultBlock
 - mArray 设备周围的所有wifi列表
 */
- (void)listWifiAp:(void(^)(NSString *connectingWifiName))wifiBlock
       returnBlock:(void(^)(NSMutableArray *mArray))resultBlock;

#pragma mark - 开启ap模式
/**
 开启ap模式
 
 @param b YES：开启ap模式，NO：切换到正常模式
 */
- (void)switchingAp:(BOOL) b returnBlock:(void(^)(BOOL success))resultBlock;

#pragma mark - 获取设备开关状态
/**
 获取设备开关状态
 
 @param resultBlock
 - uidString 设备id
 - success 错误码
 */
- (void)getDeviceCameraStatus:(void(^)(NSString *uidString,int success))resultBlock;

#pragma mark - 设备开关控制
/**
 设备开关控制
 
 @param isOpen YES 打开设备，NO 关闭设备
 @param resultBlock
 - uidString 设备id
 - success YES 成功，NO 失败
 */
- (void)setDeviceCameraStatusWithOpen:(BOOL)isOpen
                          returnBlock:(void(^)(NSString *uidString,BOOL success))resultBlock;

#pragma mark - 添加 "录制视频" 的定时任务(每次添加，需上传当前所有任务)
/**
 添加 "录制视频" 的定时任务(每次添加，需上传当前所有任务)
 data格式为："08:30-09:30\n10:00-12:30"
 组与组之间，用"\n"隔开最大85个定时任务
 
 @param array 定时任务数组
 @param resultBlock
 - success YES 成功，NO 失败
 */
- (void)addTimedRecordVideoTask:(NSArray *)array
                     returnBloc:(void(^)(BOOL success))resultBlock;

#pragma mark - 获取设备 "录制视频" 的定时列表
/**
 获取设备 "录制视频" 的定时列表
 
 @param resultBlock
 - mArray "录制视频"定时列表
 */
- (void)getTimedRecordVideoTask:(void(^)(NSMutableArray *mArray))resultBlock;

#pragma mark - 获取设备 "定时开关机" 的定时任务列表
/**
 获取设备 "定时开关机" 的定时任务列表
 
 @param resultBlock
 - mArray "开关机"定时列表
 */
- (void)getTimedCameraTask:(void(^)(NSMutableArray *mArray))resultBlock;

#pragma mark - 添加 "定时开关机" 的定时任务(每次添加，需上传当前所有任务)
/**
 添加 "定时开关机" 的定时任务(每次添加，需上传当前所有任务)
 data格式为："08:30-09:30\n10:00-12:30"
 组与组之间，用"\n"隔开最大85个定时任务
 
 @param array 定时任务数组
 @param resultBlock
 - success YES 成功，NO 失败
 */
- (void)addTimedCameraTask:(NSArray *)array
                returnBloc:(void(^)(BOOL success))resultBlock;

#pragma mark - 改变设备连接的wifi
/**
 改变设备连接的wifi
 
 @param ssid wifi账号，最大31字符
 @param pwd wifi密码，最大31字符
 @param type wifi加密方式，请看枚举AP_ENCTYPE，(wifi密码类型必须传0x03)
 @param resultBlock
 - success YES 成功，NO 失败
 */
- (void)setWifiAp:(NSString *)ssid
          withPwd:(NSString *)pwd
          andType:(NSInteger)type
       returnBloc:(void(^)(BOOL success))resultBlock;

#pragma mark - 设置视频质量
/**
 设置视频质量
 
 @param quality
 超清 = 0x01,
 高清 = 0x02,
 中等 = 0x03,
 标清 = 0x04,
 流畅 = 0x05,
 @param resultBlock
 - success YES 成功，NO 失败
 */
- (void)setVideoQuality:(int)quality
             returnBloc:(void(^)(BOOL success))resultBlock;

#pragma mark - 得到当前观看人数
/**
 得到当前观看人数
 
 @param resultBlock
 - num 观看人数
 @return YES 获取成功，NO 获取失败
 */
- (BOOL)getCurrentWatchPeoples:(void(^)(int num))resultBlock;

#pragma mark - warming
/**
 获取设备类型
 */
- (int)getDeviceType;




#pragma mark - 设置用户在录屏时，画面清晰度
/**
 设置用户在录屏时，画面清晰度
 
 @param quality 1：流程，2：标清，3：高清
 @param resultBlock
 - success YES 设置成功，NO 设置失败
 */
- (BOOL)setRecordVideoQuality:(int)quality
                  returnBlock:(void(^)(BOOL success))resultBlock;

#pragma mark - 获取用户在录屏时，画面清晰度
/**
 获取用户在录屏时，画面清晰度
 
 @param resultBlock
 - level 1：流程 2：标清 3：高清
 */
- (BOOL)getRecordVideoQuality:(void(^)(int level))resultBlock;

#pragma mark - 获取设备音量
/**
 获取设备音量
 
 @param resultBlock
 - volume 音量：0 - 100
 */
- (BOOL)getDeviceVolume:(void(^)(int volume))resultBlock;

#pragma mark - 设置设备音量
/**
 设置设备音量
 
 @param resultBlock
 - volume 音量：0 - 100
 */
- (BOOL)setDeviceVolume:(int)voice
            returnBlock:(void(^)(BOOL success))resultBlock;

#pragma mark - 设置设备移动侦测报警开关
/**
 设置设备移动侦测报警开关
 
 @param isOn YES 设备报警开，NO 设备报警关
 @param resultBlock
 - success YES 设置成功，NO 设置失败
 */
- (BOOL)setAlarmSwitch:(BOOL)isOn
           returnBlock:(void(^)(BOOL success))resultBlock;

#pragma mark - 获取设备移动侦测报警开关状态
/**
 获取设备移动侦测报警开关状态
 
 @param resultBlock
 - success YES 设备报警开，NO 设备报警关
 */
- (BOOL)getAlarmSwitch:(void(^)(BOOL success))resultBlock;

#pragma mark - 获取移动侦测等级 开启或者关闭
/**
 获取移动侦测等级 开启或者关闭
 
 @param resultBlock
 - level 由低到高 level = [1,2,3,4,5]
 */
- (BOOL)getMotionDetect:(void(^)(int level))resultBlock;

#pragma mark - 设置设备 "移动侦测" 等级
/**
 设置设备 "移动侦测" 等级
 
 @param level 由低到高 level = [1,2,3,4,5]
 @param resultBlock
 - succcess YES 设置成功，NO 设置失败
 */
- (BOOL)setMotiondetect:(int)level
            returnBlock:(void(^)(BOOL success))resultBlock;

#pragma mark - 设置设备心跳地址，设备摄像头 与 服务器 之间的心跳
/**
 设置设备心跳地址，设备摄像头 与 服务器 之间的心跳
 
 @param serviceURL 心跳地址
 @param resultBlock
 - success YES 心跳地址设置成功，NO 设置失败
 */
- (void)setHeartbeatService:(NSString *)serviceURL
                returnBlock:(void(^)(BOOL success))resultBlock;

#pragma mark - 获取设备心跳地址
/**
 获取设备心跳地址
 
 @param resultBlock
 - sUrl 返回心跳地址
 */
- (void)getHeartbeatService:(void(^)(NSString *sUrl))resultBlock;

#pragma mark - 设置心跳时间
/**
 设置心跳时间
 
 @param beatTime 0:停止 ，>= 1启用定时器
 */
- (void)setHeartbeatTime:(int)beatTime
             returnBlock:(void(^)(int mTime))resultBlock;

#pragma mark - 获取心跳时间
/**
 获取心跳时间
 
 @param resultBlock
 - mTime 心跳时间
 */
- (void)getHeartbeatTime:(void(^)(int mTime))resultBlock;

#pragma mark - 设置设备报警地址，触发报警时，调用该地址
/**
 设置设备报警地址，触发报警时，调用该地址
 
 @param ipAddress 报警地址url
 @param resultBlock
 - success YES 成功，NO 失败
 - serviceURL 报警服务器地址
 */
- (void)setphpserver:(NSString *)ipAddress
         returnBlock:(void(^)(BOOL success,NSString *serviceURL))resultBlock;

#pragma mark - 获取设备报警地址
/**
 获取设备报警地址
 
 @param resultBlock
 - success YES 成功，NO 失败
 - serviceURL 报警服务器地址
 */
- (void)getPhpserver:(void(^)(BOOL success,NSString *serviceURL))resultBlock;

#pragma mark - 获取当前设备云存储信息
/**
 获取当前设备云存储信息
 
 @param resultBlock
 - isOpen 是否开通云存储
 - cloundType 云服务类型(1全天录像，0报警录制)
 - uidString 设备id
 */
- (void)getCloundStorage:(void(^)(BOOL isOpen,int cloundType,NSString *uidString))resultBlock;

#pragma mark - 设置设备云存储功能
/**
 设置设备云存储功能
 
 @param isStart 是否打开云存储
 @param type 云服务类型(1全天录像，0报警录制)
 @param resultBlock
 - success YES 开通成功，NO 开通失败
 */
- (void)setCloundStorage:(BOOL)isStart
                 andType:(int)type
             returnBlock:(void(^)(BOOL success))resultBlock;

#pragma mark - 获取摄像头设备能力集
/**
 获取摄像头设备能力集
 */
- (void)getDeviceFunctionList:(void(^)(int isOpen))resultBlock;

#pragma mark - 设置摄像头设备能力集
/**
 设置摄像头设备能力集
 */
- (void)setDeviceFunctionListWith:(int)cap
                            block:(void(^)(int success))resultBlock;

#pragma mark - 获取设备的夜视模式
/**
 获取设备的夜视模式
 
 @param resultBlock
 - model        0:自动，1：手动(isOn YES, isOn NO) 2：定时
 - on           model = 1时，手动：YES 开，NO 关
 - timeString   model = 2时，定时："开始时间-结束时间"
 */
- (void)getIrcutModelWithBlock:(void(^)(int modeType, int isOn, NSString *time))resultBlock;

#pragma mark - 设置智能夜视模式
/**
 设置智能夜视模式
 
 @param modeType  0:自动，1：手动(isOn YES, isOn NO) 2：定时
 @param isOn ..
 @param timeInfo 定时信息
 @param resultBlock
 - success YES 设置成功，NO 设置失败
 */
- (void)setIrcutModeWithModelType:(int)modeType
                             isOn:(int)isOn
                         timeInfo:(TimeInfo *)timeInfo
                      resultBlock:(void(^)(BOOL success))resultBlock;

#pragma mark - 获取人形报警开关状态
/**
 获取人形报警开关状态
 
 @param resultBlock
 - status YES 人形检测打开，NO 关闭
 */
- (void)getPersonShapeAlarmWithBlock:(void(^)(BOOL status))resultBlock;

#pragma mark - 设置人形报警开关
/**
 设置人形报警开关
 
 @param isOn YES 打开人形检测，NO 关闭人形检测
 @param resultBlock
 - success YES 成功，NO 失败
 */
- (void)setPersonShapeAlarmWith:(int)isOn
                    returnBlock:(void(^)(BOOL success))resultBlock;

#pragma mark - 获取人脸报警开关状态

/**
 获取人脸报警开关状态
 
 @param resultBlock
 - status YES 人形检测打开，NO 关闭
 */
- (void)getPersonFaceAlarmWithBlock:(void(^)(BOOL status))resultBlock;

#pragma mark - 设置人脸报警开关
/**
 设置人脸报警开关
 
 @param isOn YES 打开人脸检测，NO 关闭人脸检测
 @param resultBlock
 - success YES 设置成功，NO 设置失败
 */
- (void)setPersonFaceAlarmWith:(int)isOn
                   returnBlock:(void(^)(BOOL success))resultBlock;

#pragma mark - 获取声音侦测开关状态
/**
 获取声音侦测开关状态
 
 @param resultBlock
 - isStart YES 已开启，NO 未开启
 */
- (void)getSoundAlarm:(void(^)(BOOL isStart))resultBlock;

#pragma mark - 设置声音侦测开关
/**
 设置声音侦测开关
 
 @param isStart 是否开启声音侦测
 @param resultBlock
 - success YES 开启成功，NO 开启失败
 */
- (void)setSoundAlarm:(BOOL)isStart
          returnBlock:(void(^)(BOOL success))resultBlock;

#pragma mark - 查询录像模式
/**
 查询录像模式
 
 @param resultBlock
 - type
 */
- (void)getVideoRecordType:(void(^)(int type))resultBlock;

#pragma mark - 设置录像模式
/**
 设置录像模式
 
 @param type    关闭录像、连续录像、定时计划、报警录像
 @param resultBlock
 - success YES 设置成功，NO 设置失败
 */
- (void)setVideoRecordType:(int)type
               returnBlock:(void(^)(BOOL success))resultBlock;

#pragma mark - 获取设备报警声音的开关状态
/**
 获取设备报警声音的开关状态
 
 @param resultBlock
 - isOpen YES 打开报警声音，NO 关闭报警声音
 */
- (void)getDeviceAlarmVolume:(void(^)(BOOL isOpen))resultBlock;

#pragma mark - 设置设备报警声音开关
/**
 设置设备报警声音开关
 
 @param isOpen YES 报警开，NO 报警关
 @param resultBlock
 - success YES 设置成功，NO 设置失败
 */
- (void)setDeviceAlarmVolume:(BOOL)isOpen
                 returnBlock:(void(^)(BOOL success))resultBlock;

#pragma mark - 获取设备电量(招财猫设备)
/**
 获取设备电量(招财猫设备)
 
 @param resultBlock
 - electriLevel 16 空电，17 1格电，18 2个格电，19 3格电，20 4格电(满格)
 */
- (void)getBatteryLevel:(void(^)(int electriLevel))resultBlock;

#pragma mark - 获取报警邮箱
/**
 获取报警邮箱
 
 @param resultBlock
 - userStr 发件人邮箱
 - userPwd 发件邮箱密码
 - serverStr 邮箱服务器
 - sendTo 收件人邮箱
 - mPort 端口
 */
- (void)getEmail:(void(^)( NSString *userStr,NSString *userPwd,NSString *serverStr,NSString *sendTo,int mPort))resultBlock;

#pragma mark - 设置报警邮箱
/**
 设置报警邮箱
 
 @param user 发件人邮箱
 @param pass 发件邮箱密码
 @param server 邮箱服务器
 @param sendO 发件人邮箱
 @param port 邮箱服务器端口
 @param resultBlock
 - success YES 设置成功，NO 设置失败
 */
- (void)setEmail:(NSString *)user
          andPwd:(NSString *)pass
       andServer:(NSString *)server
       andSendto:(NSString *)sendO
         andPort:(int)port
     returnBlock:(void(^)(BOOL success))resultBlock;

#pragma mark - 获取邮箱报警开关状态
/**
 获取邮箱报警开关状态
 
 @param resultBlock
 - isOpen YES 打开，NO 关闭
 */
- (void)getEmailAlarm:(void(^)(BOOL isOpen))resultBlock;

#pragma mark - 设置邮箱报警开关
/**
 设置邮箱报警开关
 
 @param isOpen YES 打开，NO 关闭
 @param resultBlock
 - success YES 设置成功，NO 设置失败
 */
- (void)setEmailAlarm:(BOOL)isOpen
          returnBlock:(void(^)(BOOL success))resultBlock;

#pragma mark - 获取设备别名
/**
 获取设备别名
 
 @param resultBlock
 - aliasName 别名
 - uidString 设备id
 */
- (void)getDeviceAlias:(void(^)(NSString *aliasName,NSString *uidString))resultBlock;

#pragma mark - 设置设备别名
/**
 设置设备别名
 
 @param name 别名
 @param resultBlock
 - success YES 设置成功，NO 设置失败
 */
- (void)setDeviceAlias:(NSString *)name
           returnBlock:(void(^)(BOOL success))resultBlock;

#pragma mark - 获取设备各种开关的状态，isOpen 按位计算
/**
 获取设备各种开关的状态，isOpen 按位计算
 
 @param resultBlock
 - 第0位代表枪机白光灯
 - 第1位代表智能夜视
 - 第2位代表婴儿哭声
 - 第3位代表物体检测
 */
- (void)getLampOpen:(void(^)(int isOpen))resultBlock;

#pragma mark - 设置设备各种开关的状态，isOpen 按位计算
/**
 设置设备各种开关的状态，isOpen 按位计算
 
 @param isOpen
 - 第0位代表枪机白光灯
 - 第1位代表智能夜视
 - 第2位代表婴儿哭声
 - 第3位代表物体检测
 */
- (void)setLampOpen:(int)isOpen
        returnBlock:(void(^)(BOOL success))resultBlock;

#pragma mark - 设备通用命令（433模块配置命令）
#pragma mark - 0x2 配对指令
#pragma mark - 0x3 重命名指令
#pragma mark - 0x4 获取433设备列表指令
#pragma mark - 0x5 删除指令
#pragma mark - 0x6 获取 0 撤防/ 1 布防指令
#pragma mark - 0x7 发布 0 撤防/ 1 布防指令
#pragma mark - 0x8 设置报警时间间隔指令
#pragma mark - 0x9 获取报警时间间隔指令
#pragma mark - 0x10 固件地址配置查询 (未实现)
#pragma mark - 0x11 固件地址配置设置 (未实现)
#pragma mark - 0x12 查询报警推送开关
#pragma mark - 0x13 开关报警推送
#pragma mark - 0x14 查询MQTT开关状态
#pragma mark - 0x15 开关MQTT
- (void)sendCommomCMDWithType:(int)type
                     WithData:(NSString *)dataStr
                  returnBlock:(void(^)(BOOL success,int sType, NSString * fString))resultBlock;

/**
 查询布防状态
 
 @param resultBlock
 - fenseState: 0 撤防 1 布防
 */
- (void)getDefenseState:(void(^)(int fenseState))resultBlock;
/**
 设置布防/撤防
 
 @param isDefense YES 布防， NO 撤防
 @param resultBlock 指令结果
 */
- (void)setDefense:(BOOL)isDefense returnBlock:(void(^)(BOOL success))resultBlock;
/**
 获取报警时间间隔
 
 @param resultBlock
 - success 是否成功
 - interval
 */
- (void)getAlarmInterval:(void(^)(BOOL success,int interval))resultBlock;
/**
 设置报警时间间隔
 
 @param interval 间隔秒数
 @param resultBlock
 - success
 */
- (void)setAlarmInterval:(int)interval returnBlock:(void(^)(BOOL success))resultBlock;

@end
