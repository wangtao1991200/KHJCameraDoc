//
//  TimeInfo.h
//  KHJCamera
//
//  Created by hezewen on 2018/6/8.
//  Copyright © 2018年 khj. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TimeInfo : NSObject

@property (nonatomic,strong)NSString * closeTime;
@property (nonatomic,strong)NSString * openTime;

@end
